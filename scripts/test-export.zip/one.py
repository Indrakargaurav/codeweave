print("Hello from Python!")
def greet(name):
    return f"Hello, {name}!"