console.log("Hello from JavaScript!");

function greet(name) {
    return `Hello, ${name}!`;
}