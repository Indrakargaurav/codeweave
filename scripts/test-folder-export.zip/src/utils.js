// Utility functions
export const formatDate = (date) => {
    return date.toLocaleDateString();
};